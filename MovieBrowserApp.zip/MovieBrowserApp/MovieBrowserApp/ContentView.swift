//
//  ContentView.swift
//  MovieBrowserApp
//
//  Created by Apple on 06/12/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       HomeView()
    }
}

#Preview {
    ContentView()
}
