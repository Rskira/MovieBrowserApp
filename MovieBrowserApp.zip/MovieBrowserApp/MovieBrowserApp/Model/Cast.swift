//
//  Cast.swift
//  MovieBrowserApp
//
//  Created by Apple on 07/12/24.
//

import Foundation

struct CastResponse: Decodable {
    let cast: [Cast]
}

struct Cast: Identifiable, Codable{
    let id: Int
    let name: String
    let profilePath: String?
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case profilePath = "profile_path"
    }
    
    
    var profileImageURL: URL? {
        guard let imagePath = profilePath else { return nil}
        return URL(string: "https://image.tmdb.org/t/p/w185\(imagePath)")
    }
    
    
}
