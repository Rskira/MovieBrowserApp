//
//  Video.swift
//  MovieBrowserApp
//
//  Created by Apple on 08/12/24.
//

import Foundation


struct VideoResponse: Decodable {
    let results: [Video]
}


struct Video: Decodable{
    let key: String
}
