//
//  MovieDetailViewModel.swift
//  MovieBrowserApp
//
//  Created by Apple on 07/12/24.
//

import Foundation
import Combine


class MovieDetailViewModel: ObservableObject {
    @Published var videoID: String?
    @Published var castMembers:[Cast] = []
    @Published var errorMessage:String?
    @Published var isLoading = false
    @Published var genres:[String] = []
    @Published var movieDetails: Movie?
    private var movieGenres: [Int] = []
    
    
    
    func fetchTrailer(for movideID: Int) {
        self.isLoading = true
        APIManager.shared.fetchMovieTrailer(for: movideID) { [weak self]  result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let videoID):
                    self?.videoID = videoID
                case  .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    
    func fetchMovieDetail(for movieID: Int) {
        self.isLoading = true
        APIManager.shared.fetchMovieDetails(for: movieID) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let movie):
                    self?.movieDetails = movie
                case  .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
    
    
    // here we get cast's data based on movieID passed from its view
    func fetchCastData(for movieId: Int) {
        self.isLoading = true
        APIManager.shared.fetchCast(movieID: movieId) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let cast):
                    self?.castMembers = cast
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
                
            }
        }
        
        
    }
    
    func fetchAndMapGenres(for genreIDs: [Int]) {
            if GenreManager.shared.genres.isEmpty {
                GenreManager.shared.fetchGenres { [weak self] in
                    DispatchQueue.main.async {
                        self?.mapGenres(from: genreIDs)
                    }
                }
            } else {
                mapGenres(from: genreIDs)
            }
        }
    
    func mapGenres(from genreIds: [Int]) {
        self.genres = genreIds.compactMap { GenreManager.shared.getGenreName(for: $0) }
        print("*********",genres)
    }
    
}
