//
//  HomeViewModel.swift
//  MovieBrowserApp
//
//  Created by Apple on 06/12/24.
//

import Foundation
import Combine
class HomeViewModel: ObservableObject {
    @Published var trendingMovies: [Movie] = []
    @Published var nowPlayingMovies: [Movie] = []
    @Published var topRatedMovies: [Movie] = []
    @Published var upcomingMovies: [Movie] = []
    @Published var popularMovies: [Movie] = []
    
    @Published var isLoading = false
    @Published var errorMessage: String?

    // Fetching all movie categories
    func fetchAllCategories() {
        self.isLoading = true
        
        fetchMovies(endpoint: "/trending/movie/day", for: \.trendingMovies)
        fetchMovies(endpoint: "/movie/now_playing", for: \.nowPlayingMovies)
        fetchMovies(endpoint: "/movie/top_rated", for: \.topRatedMovies)
        fetchMovies(endpoint: "/movie/upcoming", for: \.upcomingMovies)
        fetchMovies(endpoint: "/movie/popular", for: \.popularMovies)
    }

    
    private func fetchMovies(endpoint: String, for keyPath: ReferenceWritableKeyPath<HomeViewModel, [Movie]>) {
        APIManager.shared.fetchMovies(endpoint: endpoint) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let movies):
        
                    self?[keyPath: keyPath] = movies
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
