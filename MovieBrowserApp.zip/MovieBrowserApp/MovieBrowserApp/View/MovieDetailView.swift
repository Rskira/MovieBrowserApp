    //
    //  MovieDetailView.swift
    //  MovieBrowserApp
    //
    //  Created by Apple on 06/12/24.
    //

import SwiftUI
import WebKit

struct MovieDetailsView: View {
    var movie: Movie
    @StateObject private var viewModel = MovieDetailViewModel()
    @State private var selectedTab: Tab = .about
    @State private var trailerURl: String?
    @State private var playVideo:Bool = false
    @State private var isFullScreen: Bool = false
    
    enum Tab {
          case about, cast
      }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                ZStack(alignment: .bottomLeading) {
                    // video is player on Banner Image it self, seems appropriate.
                    if playVideo {
                        YouTubePlayerView(videoID: viewModel.videoID ?? "", isFullScreen: $isFullScreen)
                            .edgesIgnoringSafeArea(.all)
                            .frame(width: UIScreen.main.bounds.width, height: isFullScreen ? UIScreen.main.bounds.height : 300, alignment: .top)
                            .onChange(of: isFullScreen) { fullScreen in
                              
                                if fullScreen {
                                    UITabBar.appearance().isHidden = true
                                } else {
                                    UITabBar.appearance().isHidden = false
                                }
                            }
                    } else {
                        CustomImageView(
                            height: UIScreen.main.bounds.height * 0.30,
                            width: UIScreen.main.bounds.width,
                            imageURL: movie.bannerImageURL,
                            placeholderText: ""
                        )
                        .onTapGesture {
                
                            playVideo = true
                        }
                        
                        
                        Button(action: {
                            playVideo = true
                        }) {
                            Image(systemName: "play.fill")
                                .font(.system(size: 50))
                                .foregroundColor(.gray)
                                .padding()
                                .background(Circle().fill(Color.gray.opacity(0.10)))
                                .overlay(Circle().stroke(Color.gray, lineWidth: 2))
                                .shadow(radius: 10)
                        }
                        .frame(width: 80, height: 80)
                        .position(x: UIScreen.main.bounds.width / 2, y: UIScreen.main.bounds.height * 0.30 / 2)
                    }
                    
                    // Poster 
                    HStack(alignment: .bottom, spacing: 20) {
                        CustomImageView(
                            height: 150,
                            width: 100,
                            imageURL: movie.posterImageURL,
                            placeholderText: movie.title
                        )
                        .offset(x: 20, y: 70)
                        
                        VStack(alignment: .leading, spacing: 8) {
                            Text(movie.title)
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .offset(y:120)
                                .padding(.horizontal)
                            
                            HStack(spacing: 15) {
                                if let releaseDate = movie.releaseDate {
                                    HStack(spacing: 5) {
                                        Image(systemName: "calendar")
                                        Text(releaseDate.prefix(4))
                                    }
                                    .frame(width: 70)
                                    .foregroundColor(Color(UIColor.systemGray))
                                    .font(.footnote)
                                    
                                }
                                
                                    HStack(spacing: 5) {
                                        Image(systemName: "film")
                                        Text(viewModel.genres.first ?? "N/A")
                                    }
                                    .foregroundColor(Color(UIColor.systemGray))
                                    .font(.footnote)
                                    //.padding()
                                    .frame(width: 90)

                                
                                if let runtime = viewModel.movieDetails?.duration {
                                    HStack(spacing: 5) {
                                        Image(systemName: "clock")
                                        Text("\(runtime)min")
                                    }
                                    .frame(width: 80)
                                    .foregroundColor(Color(UIColor.systemGray))
                                    .font(.footnote)
                                    
                                }
                            }
                            .padding(.top, 20)
                            .offset(x: -60, y: 110)
                        }
                    }
                }
                Spacer(minLength: 80)
                
                HStack {
                    Button {
                        selectedTab = .about
                    } label: {
                        Text("About Movie")
                            .fontWeight(selectedTab == .about ? .bold : .regular)
                            .foregroundColor(selectedTab == .about ? .blue : .gray)
                            .padding(.bottom, 5)
                    }
                    .frame(maxWidth: UIScreen.main.bounds.width * 0.50)
                    
                    Button {
                        selectedTab = .cast
                    } label: {
                        Text("Cast")
                            .fontWeight(selectedTab == .cast ? .bold : .regular)
                            .foregroundColor(selectedTab == .cast ? .blue : .gray)
                            .padding(.bottom, 5)
                    }
                    .frame(maxWidth:  UIScreen.main.bounds.width * 0.50)
                    
                }
                .padding()
                
                Rectangle()
                    .frame(height: 2)
                    .foregroundColor(.blue)
                    .frame(width: UIScreen.main.bounds.width / 2)
                    .offset(x: selectedTab == .about ? -UIScreen.main.bounds.width / 50 : UIScreen.main.bounds.width / 2)
                    .animation(.easeInOut, value: selectedTab)
                
            }
            .onAppear {
                if let genreIds = movie.genreIds {
                    viewModel.fetchAndMapGenres(for: genreIds)
                }
                viewModel.fetchCastData(for: movie.id)
                viewModel.fetchTrailer(for: movie.id)
                viewModel.fetchMovieDetail(for: movie.id)
                
            }
            
            
            if selectedTab == .cast {
                castSection
            } else {
                aboutSection
            }
            
        }
        .background(Color.black.edgesIgnoringSafeArea(.all))
        .navigationTitle("Details")
        .onAppear {
            setupNavigationBarAppearance()
        }
        
    }
    
    private func setupNavigationBarAppearance() {
            let appearance = UINavigationBarAppearance()
            appearance.configureWithOpaqueBackground()
            appearance.backgroundColor = UIColor.black
            appearance.titleTextAttributes = [
                .foregroundColor: UIColor.white,
                .font: UIFont.systemFont(ofSize: 20)
            ]

            UINavigationBar.appearance().standardAppearance = appearance
            UINavigationBar.appearance().scrollEdgeAppearance = appearance
        }
    
    
    private var aboutSection: some View {
        VStack {
            if let overview = movie.overview {
                Text(overview)
                    .foregroundColor(.white)
                    .padding(.horizontal)
                    .padding(.top, 10)
            } else {
                Text("Overview not available.")
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                    .padding(.top, 10)
            }
        }
    }
    
    private var castSection: some View {
        
        let column = Array(repeating: GridItem(.flexible(), spacing: 10), count: 2)
        
        return ScrollView {
            LazyVGrid(columns: column, spacing: 20) {
                ForEach(viewModel.castMembers) { cast in
                    VStack {
                        if let url = cast.profileImageURL {
                            CustomImageView(height: 120, width: 120, imageURL: url, placeholderText: "DP")
                                .clipShape(Circle())
                                .scaledToFit()
                        } else {
                            Circle()
                                .fill(Color.gray.opacity(0.3))
                                .frame(width: 110, height: 110)
                        }
                        
                        Text(cast.name)
                            .font(.caption)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .lineLimit(1)
                            .padding(.top, 5)
                        
                    }
                    
                    
                }
                
            }
        }
        
    }
    
    
    
}




struct MovieDetailsView_Previews: PreviewProvider {
    static var previews: some View {
        MovieDetailsView(movie: Movie(id: 123, title: "Movie Title theeeee of last dance", posterPath: "/path/to/poster.jpg", backdropPath: "/path/to/banner.jpg", releaseDate: "2024-01-01", genreIds: [56, 12], runtime: 120, overview:"This is a great movie" ))
    }
}
