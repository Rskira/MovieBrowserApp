//
//  YoutubePlayerView.swift
//  MovieBrowserApp
//
//  Created by Apple on 08/12/24.
//

import SwiftUI
import YouTubeiOSPlayerHelper

struct YouTubePlayerView: UIViewRepresentable {
    let videoID: String
    @Binding var isFullScreen: Bool

    func makeUIView(context: Context) -> YTPlayerView {
        let playerView = YTPlayerView()
        playerView.delegate = context.coordinator
        playerView.load(withVideoId: videoID, playerVars: [
            "playsinline": 1,
            "autoplay": 1,
            "fs": 1,
            "controls": 1,
            "rel": 0,
            "modestbranding": 1
        ])
        return playerView
    }

    func updateUIView(_ uiView: YTPlayerView, context: Context) {}

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    class Coordinator: NSObject, YTPlayerViewDelegate {
        var parent: YouTubePlayerView

        init(_ parent: YouTubePlayerView) {
            self.parent = parent
        }

        func playerViewPreferredWebViewBackgroundColor(_ playerView: YTPlayerView) -> UIColor {
            .black
        }


        func playerView(_ playerView: YTPlayerView, preferredStatusBarStyleForFullScreen fullScreen: Bool) {
            DispatchQueue.main.async {
                self.parent.isFullScreen = fullScreen
            }
        }
    }
}
