//
//  MovieCategoryView.swift
//  MovieBrowserApp
//
//  Created by Apple on 08/12/24.
//

import SwiftUI

import SwiftUI

struct MovieCategoryView: View {
    let title: String
    let movies: [Movie]

    let columns = [ GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())]

    var body: some View {
        VStack(alignment: .leading) {
            // Grid for  Movies
            LazyVGrid(columns: columns, spacing: 10) {
                ForEach(movies.prefix(6), id: \.id) { movie in
                    NavigationLink(destination: MovieDetailsView(movie: movie)) {
                        CustomImageView(
                            height: 150,
                            width: 110,
                            imageURL: movie.posterImageURL,
                            placeholderText: movie.title
                        )
                    }
                }
            }
            .padding(.horizontal)
        }
    }
}

struct MovieCategoryView_Previews: PreviewProvider {
    static var previews: some View {
        MovieCategoryView(title: "Trending", movies: [Movie(id: 12, title: "jhgi", posterPath: "jhgjg", backdropPath: "jkk", releaseDate: "12/12/45", genreIds: [13,18], runtime: 7, overview: "overview"),
                                                      Movie(id: 13, title: "jhgi", posterPath: "jhgjg", backdropPath: "jkk", releaseDate: "12/12/45", genreIds: [13,18], runtime: 8, overview: "overview"),
                                                      Movie(id: 1, title: "jhgi", posterPath: "jhgjg", backdropPath: "jkk", releaseDate: "12/12/45", genreIds: [13,18], runtime: 7, overview: "overview"),
                                                                                                    Movie(id: 144, title: "jhgi", posterPath: "jhgjg", backdropPath: "jkk", releaseDate: "12/12/45", genreIds: [13,18], runtime: 8, overview: "overview"),
                                                      Movie(id: 2, title: "jhgi", posterPath: "jhgjg", backdropPath: "jkk", releaseDate: "12/12/45", genreIds: [13,18], runtime: 7, overview: "overview"),
                                                                                                    Movie(id: 18, title: "jhgi", posterPath: "jhgjg", backdropPath: "jkk", releaseDate: "12/12/45", genreIds: [13,18], runtime: 8, overview: "overview")])
    }
}
