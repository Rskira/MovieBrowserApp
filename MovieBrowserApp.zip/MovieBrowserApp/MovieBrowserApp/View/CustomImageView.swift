//
//  CustomImageView.swift
//  MovieBrowserApp
//
//  Created by Apple on 06/12/24.
//

import SwiftUI

struct CustomImageView: View {
    
    
    let height: CGFloat
    let width: CGFloat
    let imageURL: URL?
    let placeholderText: String
    
    var body: some View {
        AsyncImage(url: imageURL) { image in
            image.resizable()
                .scaledToFill()
                .frame(width: width, height: height)
                .cornerRadius(10)
        } placeholder: {
            ZStack {
                Color.gray.opacity(0.3)
                    .frame(width: width, height: height)
                
                Text(placeholderText)
                    .font(.caption)
                    .lineLimit(1)
                    .frame(width: 100, alignment: .bottom)
                    
            }
        }
        
    }
}

#Preview {
    CustomImageView(height: 150.0, width: 150.0, imageURL: URL(string: "https://image.tmdb.org/t/p/w1280/path/to/banner.jpg"), placeholderText: "")
}
