//
//  HomeView.swift
//  MovieBrowserApp
//
//  Created by Apple on 06/12/24.
//

import SwiftUI

struct HomeView: View {
    @StateObject private var viewModel = HomeViewModel()
    @State private var selectedTab = 0
    
    var body: some View {
        NavigationView {
            VStack(alignment: .leading) {
                
                Text("What do you want to watch?")
                    .font(.title3)
                    .foregroundColor(.white)
                    .padding()
                    .background(Color.black)
                // Show loading spinner when data is being fetched
                if viewModel.isLoading {
                        if viewModel.isLoading {
                            ProgressView("Loading...")
                                .progressViewStyle(CircularProgressViewStyle(tint: .white))
                                .scaleEffect(2.0)
                                .foregroundColor(.white)
                                .font(.headline)
                                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
                        }
                } else {
                    if let errorMessage = viewModel.errorMessage {
                        Text("Error: \(errorMessage)")
                            .foregroundColor(.red)
                            .padding(.horizontal)
                        
                    } else {
                        // Display movies if fetched successfully
                        VStack(alignment: .leading) {
                            Text("Trending Movies")
                                .font(.title2)
                                .padding(.horizontal)
                                .foregroundColor(.white)
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 20) {
                                    ForEach(viewModel.trendingMovies.prefix(5), id: \.id) { movie in
                                        NavigationLink(destination: MovieDetailsView(movie: movie)) {
                                            CustomImageView(height: 260, width: 170, imageURL: movie.posterImageURL, placeholderText: movie.title)
                                        }
                                    }
                                }
                                .padding(.horizontal)
                            }
                        }
                    }
                }

                VStack {
                   //tabbar
                    HStack {
                        Button(action: {
                            selectedTab = 0
                        }) {
                            Text("Now Playing")
                                .foregroundColor(selectedTab == 0 ? .blue : .gray)
                                .font(.headline)
                        }
                        Spacer()
                        Button(action: {
                            selectedTab = 1
                        }) {
                            Text("Top Rated")
                                .foregroundColor(selectedTab == 1 ? .blue : .gray)
                                .font(.headline)
                        }
                        Spacer()
                        Button(action: {
                            selectedTab = 2
                        }) {
                            Text("Upcoming")
                                .foregroundColor(selectedTab == 2 ? .blue : .gray)
                                .font(.headline)
                        }
                        Spacer()
                        Button(action: {
                            selectedTab = 3
                        }) {
                            Text("Popular")
                                .foregroundColor(selectedTab == 3 ? .blue : .gray)
                                .font(.headline)
                        }
                    }
                    .padding()
                    .background(Color.black.opacity(0.1))
                    
                    // Grid view based on selected tab
                    ScrollView {
                        switch selectedTab {
                        case 0:
                            MovieCategoryView(title: "Now Playing", movies: viewModel.nowPlayingMovies)
                        case 1:
                            MovieCategoryView(title: "Top Rated", movies: viewModel.topRatedMovies)
                        case 2:
                            MovieCategoryView(title: "Upcoming", movies: viewModel.upcomingMovies)
                        case 3:
                            MovieCategoryView(title: "Popular", movies: viewModel.popularMovies)
                        default:
                            EmptyView()
                        }
                    }
                }
                .padding(.top, 10)
            }
            .onAppear {
                // Fetching data when the view appears
                viewModel.fetchAllCategories()
            }
            .background(Color.black.edgesIgnoringSafeArea(.all)) 
                    .navigationBarHidden(true)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
