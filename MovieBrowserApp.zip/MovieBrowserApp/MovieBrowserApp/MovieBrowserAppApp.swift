//
//  MovieBrowserAppApp.swift
//  MovieBrowserApp
//
//  Created by Apple on 06/12/24.
//

import SwiftUI

@main
struct MovieBrowserAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
