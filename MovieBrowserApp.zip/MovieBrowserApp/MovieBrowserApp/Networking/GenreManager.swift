//
//  GenreManager.swift
//  MovieBrowserApp
//
//  Created by Apple on 07/12/24.
//

import Foundation
import Alamofire

class GenreManager {
    static let shared = GenreManager()
    var genres: [Int: String] = [:]
    private let apiKey = "154ad8f9017ced85e1b45f006f50d4a0"
    private let baseURL = "https://api.themoviedb.org/3"

    private init() {}

    // Fetch genres from the API and store them in the dictionary
    func fetchGenres(completion: @escaping () -> Void) {
        let url = "\(baseURL)/genre/movie/list?api_key=\(apiKey)&language=en-US"
        
        AF.request(url).responseDecodable(of: GenreListResponse.self) { response in
            switch response.result {
            case .success(let genreListResponse):
                self.genres = Dictionary(uniqueKeysWithValues: genreListResponse.genres.map { ($0.id, $0.name) })
                completion()
            case .failure(let error):
                print("Error fetching genres: \(error)")
                completion()
            }
        }
    }

    // Fetch genre name based on ID
    func getGenreName(for id: Int) -> String? {
        return genres[id]
    }
}

struct GenreListResponse: Decodable {
    let genres: [Genre]
}

struct Genre: Decodable {
    let id: Int
    let name: String
}

