//
//  ApiManager.swift
//  MovieBrowserApp
//
//  Created by Apple on 06/12/24.
//

import Foundation
import Alamofire

class APIManager {
    static let shared = APIManager()
    
    
    private let apiKey = "154ad8f9017ced85e1b45f006f50d4a0"
    private let baseURL = "https://api.themoviedb.org/3"
    
    func fetchMovies(endpoint: String, completion: @escaping (Result<[Movie], Error>) -> Void) {
        let url = "\(baseURL)\(endpoint)?api_key=\(apiKey)"
        //DispatchQueue.global().asyncAfter(deadline: .now() + 5) {   ----- I used this to check the loader screen before data is fetched.
            AF.request(url).responseDecodable(of: MovieResponse.self) { response in
                switch response.result {
                case .success(let movieResponse):
                    completion(.success(movieResponse.results))
                case .failure(let error):
                    completion(.failure(error))
                }
        //}
        }
    }
    
    
    func fetchCast(movieID: Int, completion: @escaping (Result<[Cast], Error>) -> Void) {
        
        
        let url = "\(baseURL)/movie/\(movieID)/credits?api_key=\(apiKey)"
        
        AF.request(url).responseDecodable(of: CastResponse.self) { response in
            switch response.result {
            case .success(let castResponse):
                completion(.success(castResponse.cast))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func fetchMovieDetails(for movieID: Int, completion: @escaping (Result<Movie, Error>) -> Void) {
            let url = "\(baseURL)/movie/\(movieID)?api_key=\(apiKey)&language=en-US"
            
            AF.request(url).responseDecodable(of: Movie.self) { response in
                switch response.result {
                case .success(let movieDetails):
                    completion(.success(movieDetails))
                case .failure(let error):
                    completion(.failure(error))
                }
            }
        }
    
    
    //fetch video for movie using ID
    
    func fetchMovieTrailer(for movieID: Int, completion: @escaping(Result<String, Error>) -> Void) {
        
        let url = "\(baseURL)/movie/\(movieID)/videos?api_key=\(apiKey)&language=en-US"
        print(url)
        AF.request(url).responseDecodable(of: VideoResponse.self) { response in
            switch response.result {
               
            case .success(let videoResponse):
                if let videoKey = videoResponse.results.first?.key {
                    let videoID = videoKey
                    completion(.success(videoID))
                } else {
                    let error = NSError(domain: "VideoNotFound", code: 404, userInfo: [NSLocalizedDescriptionKey: "No video key found"])
                    completion(.failure(error))
                    print("Key not found for YT")
                }
            case .failure(let error):
                completion(.failure(error))
            }
        }     
    }
    
    
    
}

